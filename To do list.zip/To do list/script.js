const inputBox = document.getElementById("input-box");
const listContainer = document.getElementById("list-container");
const addButton = document.getElementById("add-button");

// Event listener for adding a new task when "Enter" key is pressed
inputBox.addEventListener("keyup", (event) => {
    if (event.key === "Enter") {
        addTask();
    }
});

// Event listener for adding a new task when "Add" button is clicked
addButton.addEventListener("click", () => {
    addTask();
});

// Function to add a new task
function addTask() {
    const taskText = inputBox.value.trim();
    if (taskText === "") return;

    createTask(taskText);
    inputBox.value = ""; // Clear input field after adding task
}

// Function to create a new task element
function createTask(taskText) {
    const listItem = document.createElement("li");

    const checkBox = document.createElement("input");
    checkBox.type = "checkbox";
    checkBox.id = `task-${listContainer.children.length}`;

    const label = document.createElement("label");
    label.setAttribute("for", checkBox.id);

    const taskLabel = document.createElement("span");
    taskLabel.textContent = taskText;

    checkBox.addEventListener("change", () => {
        taskLabel.classList.toggle("checked", checkBox.checked); // Toggle checked class
    });

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "X";
    deleteButton.classList.add("delete-button");
    deleteButton.addEventListener("click", () => {
        listContainer.removeChild(listItem);
    });

    listItem.appendChild(checkBox);
    listItem.appendChild(label);
    listItem.appendChild(taskLabel);
    listItem.appendChild(deleteButton);
    listContainer.appendChild(listItem);
}
